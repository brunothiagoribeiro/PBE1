package prjPokemon;

public class Pokemon {
	//ATRIBUTOS
	public String nome;
	public String tipo;
	public int nivel;
	public int hp;
	
	//CONSTRUTORES
	public Pokemon() {
		
	}
	public Pokemon(String nome, String tipo, int nivel, int hp) {
		this.nome=nome;
		this.tipo=tipo;
		this.nivel=nivel;
		this.hp=hp;
	}
	//Metodos
	public void evoluir(String novoNome) {
		System.out.println(this.nome + "Evoluiu para " + novoNome);
		this.nome = novoNome;
		this.hp +=10;
		this.nivel +=1;
		
	}
	public void exibirInfo() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Tipo: " + this.tipo);
		System.out.println("Nivel: " + this.nivel);
		System.out.println("Hp: " + this.hp);
	}
	public void atacar() {
		System.out.println("Seu pokemon está atacando");
	}
}
