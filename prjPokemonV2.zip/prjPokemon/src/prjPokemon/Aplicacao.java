package prjPokemon;

public class Aplicacao {

	public static void main(String[] args) {
		
		
		Pokemon bulbassauro = new Pokemon("bulbassauro", "grama",1,70);
		Pokemon squirtle = new Pokemon("squirtle", "agua",1,70);
		Pokemon charmander = new Pokemon("charmander", "fogo",1,70);
		Pokemon pikachu = new Pokemon("pikachu", "eletrico",1,70);
		Pokemon hunter = new Pokemon("hunter", "fantasma",1,70);
		
		//Ataques + evolucao dos pokemons
		charmander.evoluir("charmeleon");
		squirtle.evoluir("wartotle");
		bulbassauro.evoluir("venossauro");
		pikachu.evoluir("raiuchu");
		hunter.evoluir("hunterzão");
	}
}