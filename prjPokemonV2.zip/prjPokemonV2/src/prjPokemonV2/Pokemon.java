package prjPokemonV2;


public class Pokemon {
	//ATRIBUTOS
	private String nome;
	private String tipo;
	private int nivel;
	private int hp;
	private int defesa;

	// Construtores
	public Pokemon() {
	}

	public Pokemon(String nome, String tipo, int nivel, int hp, int defesa) {
		this.nome = nome;
		this.tipo = tipo;
		this.nivel = nivel;
		this.hp = hp;
		this.defesa = defesa;
	}

	// METODOS SETTERS
	public void setnome(String nome) {
		this.nome = nome;
	}

	public void settipo(String tipo) {
		this.tipo = tipo;
	}

	public void setnivel(int nivel) {
		if (nivel > 0) {
			this.nivel = nivel;
		} else {
			System.out.println("Valor invalido");
		}
	}

	public void sethp(int hp) {
		if (hp > 0) {
			this.hp = hp;
		} else {
			System.out.println("Valor invalido");
		}
	}

	public void setdefesa(int defesa) {
		if (defesa > 0) {
			this.defesa = defesa;
		} else {
			System.out.println("Valor invalido");
		}
	}

	// Metodos
	public void atacar() {
		System.out.println("Seu pokemon ira voar");

	}

	public void evoluir() {
		System.out.println("Seu pokemon ira evoluir");

	}
	public void exibirInfo() {
		System.out.println("Nome "+ this.nome);
		System.out.println("Tipo "+ this.tipo);
		System.out.println("Nivel "+ this.nivel);
		System.out.println("HP "+ this.hp);
		System.out.println("Defesa "+ this.defesa);
	}
//GETTERS E SETTERS

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getDefesa() {
		return defesa;
	}

	public void setDefesa(int defesa) {
		this.defesa = defesa;
	}
	
}
