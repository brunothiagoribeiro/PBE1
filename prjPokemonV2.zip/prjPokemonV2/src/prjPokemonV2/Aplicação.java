package prjPokemonV2;

import java.util.Scanner;

public class Aplicação {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		SubClassePokemonVoador pidgey = new SubClassePokemonVoador();
		pidgey.setnome("PIDGEY");
		pidgey.settipo("Voo");
		pidgey.setnivel(14);
		pidgey.sethp(300);
		pidgey.setdefesa(1);
		
		
		SubClassePokemonVoador pidgeotto = new SubClassePokemonVoador();
		pidgeotto.setnome("pidgeotto");
		pidgeotto.settipo("Voo");
		pidgeotto.setnivel(14);
		pidgeotto.sethp(300);
		pidgeotto.setdefesa(1);
		
		SubClassePokemonAgua blastoise = new SubClassePokemonAgua();
		blastoise.setnome("Blastoise");
		blastoise.settipo("AGUA");
		blastoise.setnivel(100);
		blastoise.sethp(1000);
		blastoise.setdefesa(500);
		
		
		SubClassePokemonFogo charmander = new SubClassePokemonFogo();
		charmander.setnome("CHARMANDER");
		charmander.settipo("FOGO");
		charmander.setnivel(14);
		charmander.sethp(300);
		charmander.setdefesa(1);
		
		SubClassePokemonAgua squirtle = new SubClassePokemonAgua ();
		blastoise.setnome("SQUIRTLE");
		blastoise.settipo("AGUA");
		blastoise.setnivel(100);
		blastoise.sethp(1000);
		blastoise.setdefesa(500);
		
		SubClassePokemonFogo charmeleon = new SubClassePokemonFogo();
		charmeleon.setnome("CHARMELEON");
		charmeleon.settipo("FOGO");
		charmeleon.setnivel(14);
		charmeleon.sethp(300);
		charmeleon.setdefesa(1);
		
		Pokemon pikachu = new Pokemon();
		pikachu.setnome("PIDGEY");
		pikachu.settipo("Voo");
		pikachu.setnivel(14);
		pikachu.sethp(300);
		pikachu.setdefesa(1);
		
		
		Pokemon magnemite = new Pokemon();
		magnemite.setnome("PIDGEY");
		magnemite.settipo("Voo");
		magnemite.setnivel(14);
		magnemite.sethp(300);
		magnemite.setdefesa(1);

	}
	

}
