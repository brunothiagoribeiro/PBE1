package prjPokemonV2;

public class SubClassePokemonAgua extends Pokemon{
	// metodos da subclasse Agua
	public void atacar() {
		System.out.println("Seu pokemon irá atacar");
	}
	public void surfar() {
		System.out.println("Seu pokemon ira surfar");
	}
	public void canhaodeagua() {
		System.out.println("Seu pokemon ira utilizar um canhão de agua");
	}

}
