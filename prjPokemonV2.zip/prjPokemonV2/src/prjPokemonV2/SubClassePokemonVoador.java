package prjPokemonV2;



public class SubClassePokemonVoador extends Pokemon  {
	// metodos da subclasse Voo
		public void atacar() {
			System.out.println("Seu pokemon irá atacar");
		}
		public void voar() {
			System.out.println("Seu pokemon ira voar");
		}
		public void ataqueDeVento() {
			System.out.println("Seu pokemon ira atacar vento");
		}
}
