package prjPokemonV2;


public class SubClassePokemonFogo  extends Pokemon {
	// metodos da subclasse Fogo
		public void atacar() {
			System.out.println("Seu pokemon irá atacar");
		}
		public void bolaDeFogo() {
			System.out.println("Seu pokemon ira lançar uma bola de fogo");
		}
		public void LançaChamas() {
			System.out.println("Seu pokemon lançara chamas");
		}
        public void explosaoFogo() {
        	System.out.println("Seu pokemon expoldira fogo");
        } 
}
