package com.senaidev.saraiva.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_livro") 
public class Livro {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long livro;
	
	@Column (name = "descricao")
	String descricao;
	
	@Column (name = "isbn")
	String isbn;
	
	//CONSTRUTORES
	
	public long getLivro() {
		return livro;
	}
	
	public Livro(long livro, String descricao, String isbn) {
		super();
		this.livro = livro;
		this.descricao = descricao;
		this.isbn = isbn;
	}
	//GETTERS E SETTERS

	public void setLivro(long livro) {
		this.livro = livro;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	
}
