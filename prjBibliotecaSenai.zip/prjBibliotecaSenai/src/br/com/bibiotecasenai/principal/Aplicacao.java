package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Bibliotecario;
import br.com.bibiotecasenai.usuarios.Usuario;

public class Aplicacao {
public static void main(String[]args) {			
	Usuario usuario01 = new Usuario();
			usuario01.setCpf("00000001");
			usuario01.setNome("Vedilson");
	
			Usuario usuario02 = new Usuario();
			usuario02.setCpf("00000002");
			usuario02.setNome("Leandro");
			
			Bibliotecario bibliotecario01 = new Bibliotecario();
			bibliotecario01.setNome("Bruno");
			
	}
}

