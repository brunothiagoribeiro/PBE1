package br.com.bibiotecasenai.usuarios;

public class Pessoa {
	//Atributos
	private String nome;
	private int idade;
	
	
	//Getters e Setters
		public void setNome(String Nome) {
			this.nome = nome;
		}
		public String getNome() {
			return nome;
		}
		
		public void setIdade(int idade) {
			this.idade = idade;
		}
		public int getIdade() {
			return idade;
		}
		
		
}
