package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	//ATributos
	String matricula;
	
	public void realizarEmprestimo() {
		System.out.println("O " + this.getNome() + "emprestou o livro");
	}
	
	public void devolverLivro() {
		System.out.println("O " + this.getNome() + "devolveu o livro");
	}
	
	
	
	
}
