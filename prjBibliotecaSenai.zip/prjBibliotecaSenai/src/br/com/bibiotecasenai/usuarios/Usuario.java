package br.com.bibiotecasenai.usuarios;

public class Usuario extends Pessoa{
	//Atributps
	String cpf;
	int livrosEmprestados;
	
	//Getters e Setters
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCpf() {
		return cpf;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	
	

}
