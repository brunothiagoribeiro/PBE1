package br.com.bibiotecasenai.itens;

public class Livro {
	String titulo;
	String autor;
	String isbn;
	boolean disponivel;
	
	//Getters e Setters
		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
		public String getTitulo() {
			return titulo;
		}
		
		public void setAutor(String autor) {
			this.autor = autor;
		}
		public String getAutor() {
			return autor;
		}
		
		public void setIsbn(String isbn) {
			this.isbn = isbn;
		}
		public String getIsbn() {
			return isbn;
		}
		
}
